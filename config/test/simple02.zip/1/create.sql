create table MYTABLE (
  ID bigint(20) not null primary key,
  NAME varchar(10) character set latin1 collate latin1_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
